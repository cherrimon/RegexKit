# Firefox-RegexKit

a simple regex tool for development and testing.

This firefox extension includes:

* a browser action with a popup including HTML, CSS, and JS
* a background script
* a content script

This tool allows to search regex with affix count. The content script will search the whole HTML and highlighted the matched if possible. The search result (with captured groups) will then be sent to popup.