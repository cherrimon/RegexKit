// variable
var DEFAULT_LENGTH    	= 50;
var DEFAULT_COUNT     	= 10;
var DEFAULT_MESSAGE   	= ``;

var SAVED_LENGTH  		= 0;
var SAVED_COUNT   		= 0;
var SAVED_MESSAGE 		= "";

// listeners
browser.runtime.onMessage.addListener(routeMessage);

// message to tab
function tabMessage(payload) {
	browser.tabs.query({
		'active': true,
		'currentWindow': true
		},
		function (tabs) {
		if (typeof tabs[0].id != 'undefined' && tabs[0].id) {
			browser.tabs.sendMessage(
			tabs[0].id, 
			payload
			);
		}
	});
}

// message to popup
function popupMessage(payload) {
	browser.runtime.sendMessage(    // send to popup
		// extensionId,                 // optional string
		payload
		// options                  // optional object
		)
}

// route message
function routeMessage(request, sender, sendResponse) {
	switch (request.command) {

		case "content-response": 
			SAVED_LENGTH  = request.length;
			SAVED_COUNT   = request.count;
			SAVED_MESSAGE = request.message;
			popupMessage({
				command: request.command,
				length:  request.length,
				count:   request.count,
				message: request.message
			})
		break;

		case "popup-init":
			popupMessage({
				command: "popup-init",
				length:  DEFAULT_LENGTH,
				count:   DEFAULT_COUNT,
				message: DEFAULT_MESSAGE
			})
			if (SAVED_MESSAGE)             // have input
				popupMessage({
					command: "content-response",
					length:  SAVED_LENGTH,
					count:   SAVED_COUNT,
					message: SAVED_MESSAGE
				})
		break;

		case "popup-input": 
			DEFAULT_LENGTH  = request.length;
			DEFAULT_COUNT   = request.count;
			DEFAULT_MESSAGE = request.message;
			tabMessage({
				command: request.command,
				length:  request.length,
				count:   request.count,
				message: request.message
			});
		break;
		// default:  
	}
}
