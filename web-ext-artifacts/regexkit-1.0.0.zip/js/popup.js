// constant
const searchTxt   	= document.getElementById("searchTxt");

const lengthDnBtn 	= document.getElementById("lengthDnBtn");
const lengthTxt   	= document.getElementById("lengthTxt");
const lengthUpBtn 	= document.getElementById("lengthUpBtn");

const CountDnBtn  	= document.getElementById("CountDnBtn");
const CountTxt    	= document.getElementById("CountTxt");
const CountUpBtn  	= document.getElementById("CountUpBtn");

const sendDelay   	= 300;

const suggestRe   	= document.getElementById("suggestRe");

const resultCount 	= document.getElementById("resultCount");
const resultTxt   	= document.getElementById("resultTxt");
const resultTbl   	= document.getElementById('resultTbl');

// listener
searchTxt.addEventListener("input", 	handleInput);

lengthDnBtn.addEventListener("click", 	handleInput);
lengthTxt.addEventListener("input", 	handleInput);
lengthUpBtn.addEventListener("click", 	handleInput);

CountDnBtn.addEventListener("click", 	handleInput);
CountTxt.addEventListener("input", 		handleInput);
CountUpBtn.addEventListener("click", 	handleInput);

browser.runtime.onMessage.addListener(routeMessage);

// variable
var delayCommand = "popup-init";
var sendTimer = setTimeout(
function() { 
	backgroundMessage({
		command:  delayCommand,
		length:   lengthTxt.value,
		count:    CountTxt.value,
		message:  searchTxt.value,
		}) 
	}, 50
)
var rawResults    = [];
var savedResults  = [];

// message to background
function backgroundMessage(payload) {
	browser.runtime.sendMessage(payload);
}

function handleBtn(e){
	let val = 0;
	switch (e.target.id) {
		case "lengthDnBtn": 
			val = parseInt(lengthTxt.value, 10);
			val = val - 1;
			if (val <= 0)
				val = 0;
			lengthTxt.value = val;
		break;
		
		case "lengthUpBtn": 
			val = parseInt(lengthTxt.value, 10);  
			val = val + 1;
			lengthTxt.value = val;
		break;
		
		case "CountDnBtn": 
			val = parseInt(CountTxt.value, 10);
			val = val - 1;
			if (val <= 0)
				val = 0;
			CountTxt.value = val;
		break;

		case "CountUpBtn": 
			val = parseInt(CountTxt.value, 10);  
			val = val + 1;
			CountTxt.value = val;
		break;
		// // default:  
	}
}

// prepare message to send
function handleInput(e) {
	handleBtn(e);						// button input?
	delayCommand = "popup-input";
	clearTimeout(sendTimer);
	if (searchTxt.value){             	// have input
		sendTimer = setTimeout(
		function() { 
			backgroundMessage({
			command:  delayCommand,
			length:   lengthTxt.value,
			count:    CountTxt.value,
			message:  searchTxt.value,
			}) 
		}, sendDelay
		)		
	}
}

// route message
function routeMessage(request, sender, sendResponse) {
	
	if (request.command == "popup-init"){	// popup requires initialization
		lengthTxt.value = request.length;
		CountTxt.value =  request.count;
		searchTxt.value = request.message;	
	// } else if (request.command == "content-response"){
	} else {								// upon response from content
		rawResults      = request.message
		savedResults    = request.message
		resultCount.innerText = request.count;
		refreshTbl(savedResults)
	}
}

// create captured group list
function capturedList(pattern, data){
	var container = document.createElement("div");
	container.style.width 		= "80px"
	container.style.overflow 	= "auto"
	let table 	= document.createElement('table');	// prepare for output
	let header	= table.createTHead();;
	const re = new RegExp(pattern, 'gi');
	let match = re.exec(data);
	if (match.length > 1){							// skip the whole result
		for (let i = 1; i < match.length; i++){		// compute captured list
			let row     = header.insertRow();
			let cell 	= row.insertCell();
			let cg  	= document.createTextNode(match[i]);
			cell.appendChild(cg);
		}
	}
	container.append(table);
	return container;
}

// format result: set affix font to gray
function formatResult(length, data){
	var container = document.createElement("div");
	container.style.overflow = "auto"
	var s1 = document.createElement("span");
	var s2 = document.createElement("span");
	var s3 = document.createElement("span");
	s1.textContent = data.substring(0, length);
	s2.textContent = data.substring(length, data.length - length);
	s3.textContent = data.substring(data.length - length);
	s1.style.color = "gray";
	s3.style.color = "gray";
	container.append(s1, s2, s3);
	return container;
}

// refresh table
function refreshTbl(data) {
	document.getElementById("resultTbl").innerHTML = "";
	let table       	= document.getElementById("resultTbl");
	table.style.margin 	= "0px 0px 0px 10px"
	let header      	= table.createTHead();
	let row         	= header.insertRow(0);
	let resultHead 		= row.insertCell();
	let rh  = document.createTextNode(`${lengthTxt.value} + Pattern + ${lengthTxt.value}`);
	resultHead.appendChild(rh);

	let captureHead = row.insertCell();
	let ch  = document.createTextNode("(?)");
	captureHead.appendChild(ch);

	for (let i = 0; i < data.length; i++) {
		row     	= header.insertRow(i + 1);
		resultCol 	= row.insertCell();
		capturedCol = row.insertCell();
		
		let innerResult  = formatResult(
			lengthTxt.value, 
			data[i]
			);
		resultCol.appendChild(innerResult);

		let innerTable = capturedList(
			searchTxt.value, 
			data[i]
			)
		capturedCol.appendChild(innerTable);
	}
}

