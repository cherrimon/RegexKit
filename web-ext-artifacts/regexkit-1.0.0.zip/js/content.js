// constant
var ELEMENT_NODE_TYPE = 1;
var TEXT_NODE_TYPE = 3;
var UNEXPANDABLE = /(script|style|svg|audio|canvas|figure|video|select|input|textarea)/i;
var HIGHLIGHT_TAG = 'highlight-tag';
var HIGHLIGHT_CLASS = 'highlighted';
var SELECTED_CLASS = 'selected';
var DEFAULT_MAX_RESULTS = 500;
var DEFAULT_HIGHLIGHT_COLOR = '#ffff00';
var DEFAULT_SELECTED_COLOR = '#ff9900';
var DEFAULT_TEXT_COLOR = '#000000';
var DEFAULT_CASE_INSENSITIVE = false;

// listener
browser.runtime.onMessage.addListener(routeMessage);

// variable
var searchInfo;

/* Initialize search information for this tab */
function initSearchInfo(pattern) {
	var pattern = typeof pattern !== 'undefined' ? pattern : '';
	searchInfo = {
		regexString : pattern,
		selectedIndex : 0,
		highlightedNodes : [],
		length : 0
	}
}

(function() {
	initSearchInfo();
})();

// message to background
function backgroundMessage(payload) {
	browser.runtime.sendMessage(    // send to popup
		// extensionId,                 // optional string
		payload
		// options                  // optional object
		)
}

/* Check if the given node is a text node */
function isTextNode(node) {
	return node && node.nodeType === TEXT_NODE_TYPE;
}

/* Check if the given node is an expandable node that will yield text nodes */
function isExpandable(node) {
	return node && node.nodeType === ELEMENT_NODE_TYPE && node.childNodes && 
	// !UNEXPANDABLE.test(node.tagName) && node.visible();
	// !UNEXPANDABLE.test(node.tagName) && node.style.visibility === 'visible';
	!UNEXPANDABLE.test(node.tagName);
}

/* Highlight all text that matches regex */
function highlight(regex, highlightColor, selectedColor, textColor, maxResults) {
	function highlightRecursive(node) {
		if(searchInfo.length >= maxResults){
		return;
		}
		if (isTextNode(node)) {
		var index = node.data.search(regex);
		if (index >= 0 && node.data.length > 0) {
			var matchedText = node.data.match(regex)[0];
			var matchedTextNode = node.splitText(index);
			matchedTextNode.splitText(matchedText.length);
			var spanNode = document.createElement(HIGHLIGHT_TAG); 
			spanNode.className = HIGHLIGHT_CLASS;
			spanNode.style.backgroundColor = highlightColor;
			spanNode.style.color = textColor;
			spanNode.appendChild(matchedTextNode.cloneNode(true));
			matchedTextNode.parentNode.replaceChild(spanNode, matchedTextNode);
			searchInfo.highlightedNodes.push(spanNode);
			searchInfo.length += 1;
			return 1;
		}
		} else if (isExpandable(node)) {
		var children = node.childNodes;
		for (var i = 0; i < children.length; ++i) {
			var child = children[i];
			i += highlightRecursive(child);
		}
		}
		return 0;
	}
	highlightRecursive(document.getElementsByTagName('body')[0]);
};

/* Remove all highlights from page */
function removeHighlight() {
	while (node = document.body.querySelector(HIGHLIGHT_TAG + '.' + HIGHLIGHT_CLASS)) {
		node.outerHTML = node.innerHTML;
	}
		while (node = document.body.querySelector(HIGHLIGHT_TAG + '.' + SELECTED_CLASS)) {
		node.outerHTML = node.innerHTML;
	}
};

// route message
function routeMessage(request, sender, sendResponse) {
	switch (request.command) {
		case "popup-input":
		computeRegex(
			request
		);
		break;
	}
}

// return regex results
function computeResults(
	pattern, 
	length,
	src
	){
	pattern = String.raw`([\s\S]{${length}}${pattern}[\s\S]{${length}})`;
	let re = new RegExp(pattern, 'gi');
	return src.match(re);
}

// return regex results
function computeRegex(request){
	// reset highlighted content if necessary
	removeHighlight();

	// generate result by popup message
	let results = computeResults(
		request.message, 
		request.length,
		document.documentElement.innerHTML
		);
		
	// highlight the content if possible
	var regex           = new RegExp(request.message);
	var highlightColor  = '#ffff00';
	var selectedColor   = '#ff9900';
	var textColor       = '#000000';
	var maxResults      = 500;
	highlight(
		regex, 
		highlightColor, 
		selectedColor, 
		textColor, 
		maxResults
		);
		
	// at most 10 results
	if (results == null)                      // nothing return
		results = []                            // empty array
	let resultCount = results.length;
	if (results.length > request.count){
		results.length = request.count;
	}

	// send result to popup
	backgroundMessage({
		command: "content-response",
		length:  request.length,
		count:   resultCount,
		message: results
	});
}